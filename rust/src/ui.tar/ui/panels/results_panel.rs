use std::collections::{BTreeMap, BTreeSet};
use std::path::{Path, PathBuf};

use eframe::egui;

use crate::ui::state::SameFileApp;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum GroupBadge {
    Internal,
    Shared,
    Mixed,
}

pub fn draw_results_panel(app: &mut SameFileApp, ui: &mut egui::Ui) {
    ui.group(|ui| {
        ui.horizontal(|ui| {
            ui.heading("Duplicate Result");

            ui.separator();

            ui.checkbox(&mut app.show_folder_grouping, "Folder grouping");

            if ui.button("Clear Selection").clicked() {
                app.selected_duplicate_index = None;
            }
        });

        ui.separator();

        // ← ここがポイント: cloneして app から切り離す
        let Some(summary) = app.last_summary.clone() else {
            ui.label("No results yet.");
            return;
        };

        let target_root = normalize_target_root(&app.target_path);

        egui::ScrollArea::both()
            .id_salt("dup_scroll_rich")
            .auto_shrink([false; 2])
            .show(ui, |ui| {
                for (group_idx, group) in summary.duplicate_groups.iter().enumerate() {
                    let badge = classify_group_badge(&group.files, target_root.as_deref());
                    let folder_map = build_folder_map(&group.files);

                    let header_text = format!(
                        "[Group {}] {}  hash={}  count={}  size={} bytes",
                        group_idx + 1,
                        badge_label(badge),
                        group.hash_hex,
                        group.files.len(),
                        group.file_size_bytes
                    );

                    let header_color = match badge {
                        GroupBadge::Internal => egui::Color32::from_rgb(120, 210, 140),
                        GroupBadge::Shared => egui::Color32::from_rgb(120, 180, 255),
                        GroupBadge::Mixed => egui::Color32::from_rgb(230, 200, 110),
                    };

                    egui::CollapsingHeader::new(
                        egui::RichText::new(header_text)
                            .monospace()
                            .strong()
                            .color(header_color),
                    )
                    .id_salt(("dup_group", group_idx))
                    .default_open(true)
                    .show(ui, |ui| {
                        if app.show_folder_grouping {
                            for (folder, files) in &folder_map {
                                let folder_label = format!("📁 {}  ({})", folder, files.len());

                                egui::CollapsingHeader::new(
                                    egui::RichText::new(folder_label)
                                        .monospace()
                                        .color(egui::Color32::from_rgb(180, 180, 220)),
                                )
                                .id_salt(("dup_group_folder", group_idx, folder))
                                .default_open(true)
                                .show(ui, |ui| {
                                    for file_path in files {
                                        draw_file_row(app, ui, file_path);
                                    }
                                });
                            }
                        } else {
                            for file_path in &group.files {
                                draw_file_row(app, ui, file_path);
                            }
                        }
                    });

                    ui.add_space(4.0);
                }
            });
    });
}

fn draw_file_row(app: &mut SameFileApp, ui: &mut egui::Ui, file_path: &PathBuf) {
    let selected = is_selected_path(app, file_path);

    let response = ui.selectable_label(
        selected,
        egui::RichText::new(file_path.display().to_string())
            .monospace()
            .color(egui::Color32::from_rgb(210, 210, 210)),
    );

    if response.clicked() {
        select_path_in_duplicate_rows(app, file_path);
    }

    if response.double_clicked() {
        select_path_in_duplicate_rows(app, file_path);
        app.reveal_selected_in_explorer();
    }
}

fn is_selected_path(app: &SameFileApp, target: &Path) -> bool {
    let Some(idx) = app.selected_duplicate_index else {
        return false;
    };
    let Some(row) = app.duplicate_rows.get(idx) else {
        return false;
    };
    let Some(path) = &row.path else {
        return false;
    };
    path == target
}

fn select_path_in_duplicate_rows(app: &mut SameFileApp, target: &Path) {
    if let Some((idx, _)) = app
        .duplicate_rows
        .iter()
        .enumerate()
        .find(|(_, row)| row.path.as_deref() == Some(target))
    {
        app.selected_duplicate_index = Some(idx);
    } else {
        app.selected_duplicate_index = None;
    }
}

fn build_folder_map(files: &[PathBuf]) -> BTreeMap<String, Vec<PathBuf>> {
    let mut map: BTreeMap<String, Vec<PathBuf>> = BTreeMap::new();

    for p in files {
        let folder = p
            .parent()
            .map(|d| d.display().to_string())
            .unwrap_or_else(|| "(no parent)".to_string());

        map.entry(folder).or_default().push(p.clone());
    }

    map
}

fn classify_group_badge(files: &[PathBuf], target_root: Option<&Path>) -> GroupBadge {
    if files.is_empty() {
        return GroupBadge::Internal;
    }

    let mut parent_set = BTreeSet::<String>::new();
    let mut has_under_root = false;
    let mut has_outside_root = false;

    for p in files {
        if let Some(parent) = p.parent() {
            parent_set.insert(parent.display().to_string());
        }

        if let Some(root) = target_root {
            if p.starts_with(root) {
                has_under_root = true;
            } else {
                has_outside_root = true;
            }
        } else {
            has_under_root = true;
        }
    }

    if has_under_root && has_outside_root {
        return GroupBadge::Mixed;
    }

    if parent_set.len() <= 1 {
        GroupBadge::Internal
    } else {
        GroupBadge::Shared
    }
}

fn badge_label(badge: GroupBadge) -> &'static str {
    match badge {
        GroupBadge::Internal => "INTERNAL",
        GroupBadge::Shared => "SHARED",
        GroupBadge::Mixed => "MIXED",
    }
}

fn normalize_target_root(raw: &str) -> Option<PathBuf> {
    let s = raw.trim().trim_matches('"').trim_matches('\'').trim();
    if s.is_empty() {
        return None;
    }
    Some(PathBuf::from(s))
}