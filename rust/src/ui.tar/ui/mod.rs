pub mod egui_app;
pub mod state;
pub mod actions;
pub mod events;
pub mod panels;

// 外からは SameFileApp をこれで使えるようにしておくと楽
pub use state::SameFileApp;